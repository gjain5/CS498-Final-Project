# Find out more at http://compass-style.org/help/documentation/configuration-reference/
add_import_path "public/lib/foundation-sites/scss"
css_dir = 'public/css'
sass_dir = 'source_sass'
/* Sample Controller */

app.controller('detailsController', ['$scope', '$http', '$routeParams', function($scope, $http, $routeParams) {
	
	$http.get('data/imdb250.json').success(function(data) {
		$scope.datastore = data;
	}) 
	
	$scope.index = $routeParams.rank;
	
	$scope.goLeft = function()
	{
		if($scope.index <= 1)
			$scope.index = $scope.datastore[$scope.datastore.length - 1].rank + 1;
	};
	
	$scope.goRight = function()
	{
		if ($scope.index >= $scope.datastore.length)
			$scope.index = 0;
	}
	
}]);

app.controller('listController', ['$scope', '$http', function($scope, $http) {

	$http.get('data/imdb250.json').success(function(data) {
		$scope.datastore = data;
	}) 
	
	$scope.drop = {};
	$scope.drop.down = 'title';
	$scope.dropdowns = [
		{'name': 'Title',
		 'value': 'title'},
		{'name': 'Rank',
		 'value': 'rank'}
	];
	
	$scope.flag  = 0;
	$scope.query = {'title':'','rank':'','imdbRating':''};

	
}]);

app.controller('galleryController', ['$scope', '$http', function($scope, $http) {
	
	$http.get('data/imdb250.json').success(function(data) {
		$scope.datastore = data;
	})
	
	$scope.selectedGenre = "All";
	$scope.genres = ['All', 'Action', 'Adventure', 'Animation', 'Biography', 'Comedy', 'Crime', 'Drama', 'Family', 'Fantasy', 'Film-Noir', 'History', 'Horror', 'Music', 'Musical', 'Mystery', 'Romance', 'Sci-Fi', 'Sport', 'Thriller', 'War', 'Western'];
	
	$scope.filterByGenres = function(movie) {
		if ($scope.selectedGenre == "All")
			return 1;
		
		return (movie.genre.indexOf($scope.selectedGenre) !== -1);
    };
	
	$scope.selectedIndex = 0;
	$scope.updateGenre = function (value, index)
	{
		$scope.selectedGenre = value;
		$scope.selectedIndex = index;
	}
	
}]);
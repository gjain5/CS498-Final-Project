/*
 * You generally want to .gitignore this file to prevent important credentials from being stored on your public repo.
 */
module.exports = {
    token : "secret-llama",
    mongo_connection : "mongodb://cs498rk:cs498rk@ds040489.mlab.com:040489/tasker"
};

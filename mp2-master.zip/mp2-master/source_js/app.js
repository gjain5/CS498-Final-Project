var app = angular.module('mp3',['ngRoute']);

app.config(function ($routeProvider) {

})

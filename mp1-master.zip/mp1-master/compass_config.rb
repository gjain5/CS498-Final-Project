# Find out more at http://compass-style.org/help/documentation/configuration-reference/
css_dir = 'public/css'
sass_dir = 'source_sass'
javascripts_dir = 'js'
output_style = :compressed #change this to :nested if you want readable CSS
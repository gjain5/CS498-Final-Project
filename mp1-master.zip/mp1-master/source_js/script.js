// smooth scrolling
	$(function() {
  $("nav a").click(function() {
      var target = $(this.hash);
      if (target.length) {
        $('html,body').animate({ scrollTop: target.offset().top-77 }, 1000);
        return false;
      }
  });
});


// nav-bar on top and resize
(function($) {
    "use strict";

    var $navbar = $("#navbar"),
        y_pos = $navbar.offset().top,
        height = $navbar.height();

    $(document).scroll(function() {
        var scrollTop = $(this).scrollTop();

        if (scrollTop > y_pos + height) {
            $navbar.addClass("navbar-fixed").animate({
                top: 0
            });
        } else if (scrollTop <= y_pos) {
            $navbar.removeClass("navbar-fixed").clearQueue().animate({
                top: "-48px"
            }, 0);
        }
    });

})(jQuery, undefined);

var slideIndex = 1;
showSlides(slideIndex);

function next(n) {
  showSlides(slideIndex += n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("carousel");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  slides[slideIndex-1].style.display = "block";
}   



  
/* 

References:

http://www.w3schools.com/howto/howto_js_slideshow.asp
https://codepen.io/nicklolsen/pen/GyFzk/
https://css-tricks.com/perfect-full-page-background-image/

*/

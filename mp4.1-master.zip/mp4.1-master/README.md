# Starter files for MP4

## Setup
Use the following commands in your vagrant development environment to get this up and running
```
git clone https://github.com/uiuc-web-programming/mp4_client_starter.git
cd mp4_client_starter
npm install
bower install
grunt
```

You can leave this command running in the background while development for livereloading:

```bash
grunt
```
